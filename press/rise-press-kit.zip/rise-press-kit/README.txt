RISE — PRESS KIT
riseos.care

Press contact: jesse@riseos.care

WHAT IS IN HERE
  01-logos/svg   the arc mark, the wordmark and the star, as vectors.
                 Use these wherever you can. They scale to anything.
  01-logos/png   the same marks at 512, 1024 and 2048 px wide, on a
                 transparent ground. Use where SVG is not accepted.
  02-colour      the full palette as a sheet and as a plain hex list.
  03-imagery     photography and artwork, cleared for editorial use.
  04-boilerplate.txt   approved descriptions, company facts, contact.

USING THE MARKS
  Ink (#1E1F21) on light grounds. White on dark grounds and on
  photography. Amber (#F59432) is the mark's own colour and is for the
  arc mark only — the wordmark is never set in amber.

  Keep clear space around the mark equal to the height of its dot on
  every side. Nothing enters that space.

  Minimum size: the arc mark 20 px tall, the wordmark 80 px wide.

  Do not recolour, stretch, rotate, outline, add shadows or gradients,
  reconstruct the arc from parts, or set the mark on a busy background
  where it stops reading.

FONTS ARE NOT INCLUDED
  Rise sets display copy in Rounded and its italic accent in Editorial
  New. Both are licensed to Rise and cannot be redistributed. Body copy
  is DM Sans, which is open source and available from Google Fonts.
  For headlines in a publication's own layout, use your own faces.

IMAGERY
  The photography and artwork here may be used in editorial coverage of
  Rise. The people shown are not Rise customers or employees; do not
  caption them as such. Partner and university logos are deliberately
  not included in this kit.

This kit is generated from the Rise site's own source. If something in
it looks wrong or out of date, write to jesse@riseos.care.
